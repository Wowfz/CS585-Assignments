import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Hashtable;

public class ui {
    public JSlider slider1;
    private JPanel p1;
    private JButton runButton;
    private JSlider slider2;
    private JTextPane textPane1;
    private JTextArea textArea1;
    private JButton nextFrameButton;
    private JButton previousFrameButton;
    private JComboBox comboBox1;
    private JCheckBox keepIDInvariableCheckBox;
    private JButton outputVideoButton;
    private JRadioButton batViewBatIDRadioButton;
    private JRadioButton normalCameraViewRadioButton;
    private JButton stopButton;
    private JButton confirmButton;
    private JButton calculateBatsInFOVButton;
    private JComboBox comboBox2;
    private JTextArea textArea2;
    private JTextField textField1;
    private JButton button1;
    private JPanel panel1;

    public int aspect = 45;
    public FinalProject p;
    public String last_choose_id;
    public boolean inexchange = false;

    public ui(FinalProject fp) {
        p = fp;

        Hashtable labelTable = new Hashtable();
        for (int i = 0; i <= 30; i+=1) {
            labelTable.put(new Integer(i), new JLabel(String.valueOf(i/10.0)));
        }

        slider2.setValue(0);
        slider2.setMinimum(0);
        slider2.setMaximum(1098);
        // 设置主刻度间隔
        slider2.setMajorTickSpacing(200);
        // 设置次刻度间隔
        slider2.setMinorTickSpacing(50);
        // 绘制 刻度 和 标签
        slider2.setPaintTicks(true);
        slider2.setPaintLabels(true);

        slider2.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                System.out.println("Slider 2 changes" + slider2.getValue());
                fp.frame = slider2.getValue();
                comboBox1.removeAllItems();
                for (int i = 0; i < fp.ui_bat.get(fp.frame).size(); i++) {

                    comboBox1.addItem(fp.ui_bat.get(fp.frame).get(i).id);

                }
            }
        });

        runButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] args = new String[]{"0"};
                //p.main(args,aspect);
            }
        });
        nextFrameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (fp.frame < 1098)
                    fp.frame++;
                comboBox1.removeAllItems();
                textArea2.setText("");
                textArea2.append("frame: " + Integer.toString(fp.frame)+'\n');
                textArea2.append("Id: " + Integer.toString(fp.bat_id) + '\n');
                for (int i = 0; i < fp.ui_bat.get(fp.frame).size(); i++) {
                    comboBox1.addItem(fp.ui_bat.get(fp.frame).get(i).id);
                }
            }
        });

        previousFrameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (fp.frame > 0)
                    fp.frame--;
                comboBox1.removeAllItems();
                textArea2.setText("");
                textArea2.append("frame: " + Integer.toString(fp.frame)+'\n');
                textArea2.append("Id: " + Integer.toString(fp.bat_id) + '\n');
                for (int i = 0; i < fp.ui_bat.get(fp.frame).size(); i++) {

                    comboBox1.addItem(fp.ui_bat.get(fp.frame).get(i).id);

                }
            }
        });

        comboBox1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String selectedItem = "0";
                if (ItemEvent.SELECTED == e.getStateChange() && !inexchange) {
                    selectedItem = e.getItem().toString();
                    fp.bat_id = Integer.parseInt(selectedItem);
                    textArea2.append("Id: " + Integer.toString(fp.bat_id) + '\n');
                }
            }
        });

        keepIDInvariableCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inexchange = keepIDInvariableCheckBox.isSelected();
            }
        });

        ButtonGroup btnGroup = new ButtonGroup();
        btnGroup.add(batViewBatIDRadioButton);
        btnGroup.add(normalCameraViewRadioButton);
        batViewBatIDRadioButton.setSelected(true);
        batViewBatIDRadioButton.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(batViewBatIDRadioButton.isSelected())
                    fp.batview = true;
                else
                    fp.batview = false;
            }
        });
        runButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fp.autoplay = true;
            }
        });
        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fp.autoplay = false;
            }
        });
        outputVideoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fp.write = true;
            }
        });
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fp.frame = Integer.parseInt(textArea1.getText());
                textArea2.setText("");
                textArea2.append("frame: " + Integer.toString(fp.frame)+'\n');
                textArea2.append("Id: " + Integer.toString(fp.bat_id) + '\n');
                comboBox1.removeAllItems();
                for (int i = 0; i < fp.ui_bat.get(fp.frame).size(); i++) {
                    comboBox1.addItem(fp.ui_bat.get(fp.frame).get(i).id);
                }
            }
        });
        calculateBatsInFOVButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fp.calculate_fov = true;
            }
        });

        comboBox2.addItem("0.01");
        comboBox2.addItem("0.02");
        comboBox2.addItem("0.03");
        comboBox2.addItem("0.04");
        comboBox2.addItem("0.05");
        comboBox2.addItem("0.06");
        comboBox2.addItem("0.07");
        comboBox2.addItem("0.08");
        comboBox2.addItem("0.09");
        comboBox2.addItem("0.10");
        comboBox2.addItem("0.11");
        comboBox2.addItem("0.12");
        comboBox2.addItem("0.13");
        comboBox2.setSelectedIndex(10);
        comboBox2.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String selectedItem = e.getItem().toString();
                fp.focal_length = Float.parseFloat(selectedItem);
            }
        });

        slider1.setValue(35);
        slider1.setMinimum(0);
        slider1.setMaximum(120);
        // 设置主刻度间隔
        slider1.setMajorTickSpacing(15);
        // 设置次刻度间隔
        slider1.setMinorTickSpacing(5);
        // 绘制 刻度 和 标签
        slider1.setPaintTicks(true);
        slider1.setPaintLabels(true);
        slider1.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                fp.aspect_angle = slider1.getValue();
            }
        });


    }

    public void run(){
        JFrame frame = new JFrame("ui");
        frame.setContentPane(new ui(p).p1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(800,600);
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
