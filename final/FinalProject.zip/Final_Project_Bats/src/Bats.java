import com.jogamp.opengl.util.gl2.GLUT;

import javax.media.opengl.GL;
import javax.media.opengl.GL2;

import java.util.*;

import static javax.media.opengl.GL.GL_LINES;
import static javax.media.opengl.GL2.GL_LIST_BIT;
import static jogamp.opengl.windows.wgl.WGL.wglGetCurrentDC;

public class Bats {

    public int id = 0;

    // world coordinate
    public float x;
    public float y;
    public float z;

    // camera coordinate
    public float xc;
    public float yc;
    public float zc;

    // projection coordinate
    public float xp;
    public float yp;
    public float zp;

    public float dir_x;
    public float dir_y;
    public float dir_z;

    public float color_r;
    public float color_g;
    public float color_b;

    public Bats(int id_, float x_, float y_, float z_)
    {
        id = id_;
        x = x_;
        y = y_;
        z = z_;
        dir_x = 0;
        dir_y = 0;
        dir_z = 0;
        xc = x;
        yc = y;
        zc = z;

    }

    private int bats_object,body;
    /**
     * The default number of slices to use when drawing the sphere.
     */
    public static final int DEFAULT_SLICES = 36;
    /**
     * The default number of stacks to use when drawing the sphere.
     */
    public static final int DEFAULT_STACKS = 28;

    public void init( GL2 gl , float[][] randcolor)
    {
        color_r = randcolor[id][0];
        color_g = randcolor[id][1];
        color_b = randcolor[id][2];

        // draw all parts of the predator
        draw_body(gl);

        bats_object = gl.glGenLists(1);
        gl.glNewList( bats_object, GL2.GL_COMPILE );
        GLUT glut = new GLUT();
        // update the location and orientation
        construct_disp_list( gl );
        gl.glEndList();
    }

    //draw body of predator
    private void draw_body(GL2 gl){
        body = gl.glGenLists(1);
        gl.glNewList(body, GL2.GL_COMPILE );
        GLUT glut = new GLUT();

        //gl.glPushMatrix();
        //gl.glPopMatrix();

        gl.glPushMatrix();
        //gl.glScalef(0.5f, 0.5f, 0.5f);
        glut.glutSolidSphere(0.1,DEFAULT_SLICES,DEFAULT_STACKS);
        float curSizeLine=2;
//    glGetFloatv(GL_LINE_WIDTH_RANGE,sizesLine);

//    glGetFloatv(GL_LINE_WIDTH_GRANULARITY,&stepLine);
        gl.glLineWidth(curSizeLine);
        gl.glBegin(GL_LINES);
        gl.glVertex3f(0,0,0);
        gl.glVertex3f((0+5*dir_x),(0+5*dir_y),(0+5*dir_z));
        gl.glEnd();
        gl.glPopMatrix();

        gl.glEndList();
    }

    //private float scale;
    //draw the model and make the it face to the direction it moves
    private void construct_disp_list( GL2 gl)
    {
        gl.glPushMatrix();

        //gl.glScalef(scale, scale, scale);

        // get the transforming matrix that make the model face the direction of movement

        // get the move distance in x y z in last frame, it is the velocity on x y z axis
        float dx = dir_x;
        float dy = dir_y;
        float dz = dir_z;


        // normalized
        //float mag = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        // store the velocity vector
        Vector3D v = new Vector3D(dx,dy,dz);
        v.normalize();
        //v[0] = dx / mag;
        //v[1] = dy / mag;
        //v[2] = dz / mag;

        // assume up vector is 0,1,0
        Vector3D up = new Vector3D(0.0f, 1.0f, 0.0f );
        up.normalize();

        Vector3D right = v.crossProduct(up);
        right.normalize();

        up = right.crossProduct(v);
        // cross product v vector and up vector get right vector
        //float[] right = {v[1] * up[2] - up[1] * v[2], v[2] * up[0] - v[0] * up[2], v[0] * up[1] - v[1] * up[0]};

        // use v, right, up vector and x,y,z to make new transforming matrix
        float[] rotationMatrix = { v.x, v.y, v.z, 0.0f, up.x, up.y, up.z, 0.0f, right.x, right.y, right.z, 0.0f, x, y, z, 1.0f };

        // use current matrix to multiply the new transforming matrix to change the model's location and face to direction
        gl.glMultMatrixf(rotationMatrix, 0);

        // set predator's color

        //gl.glRotated(angle, 1, 1, 0);
        //gl.glRotated(tailAngle + 90, 0, 1, 0);


        gl.glColor3f(color_r, color_g, color_b); //green
        //body
        gl.glPushMatrix();
        gl.glCallList( body );
        gl.glPopMatrix();

        gl.glPopMatrix();
    }

    public void update( GL2 gl )
    {
        gl.glNewList(bats_object, GL2.GL_COMPILE );

        // draw the new model in new location and direction
        construct_disp_list( gl );
        gl.glEndList();
    }

    public void draw( GL2 gl )
    {
        gl.glPushMatrix();
        gl.glCallList( bats_object );
        gl.glPopMatrix();
    }

}
