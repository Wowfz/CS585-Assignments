//Chanan Suksangium Point3D to handle z-buffer

public class Point3D
{
	public float x, y, z;

	public Point3D(float _x, float _y, float _z)
	{
		x = _x;
		y = _y;
		z = _z;
	}

	public Point3D( Point3D p)
	{
		x = p.x;
		y = p.y;
		z = p.z;
	}
}