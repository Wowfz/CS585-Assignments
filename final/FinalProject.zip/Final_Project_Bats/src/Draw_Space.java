import javax.media.opengl.GL2;
import java.util.List;
import java.util.Random;

public class Draw_Space
{
  //public List<List<Bats>> bats = new ArrayList<>();
  public int frame = 0;
  private Random rand = new Random();
  public float[][] randcolor = new float[250][3];

  public Draw_Space()
  {
    //bats = FinalProject.;
    //tank = new Tank( 4f, 4f, 4f );
    //fishes.add(new Fish(1f,-0.9f,0.3f,0.3f, this));
    //predators.add(new Predator(1f,0f,-0.9f,-0.7f));
    //predators.get(0).getprey(fishes.get(0));
    //fishes.get(0).getpredator(predators.get(0));

    for(int i = 0; i<250; i++)
    {
      randcolor[i][0] = rand.nextFloat();
      randcolor[i][1] = rand.nextFloat();
      randcolor[i][2] = rand.nextFloat();
    }
  }

  public void init( GL2 gl,List<List<Bats>> bats, int framenum, int camera_id)
  {
    //tank.init( gl );
    if(bats != null)
    if(bats.get(framenum)!=null)
    for(int bat_num = 0; bat_num < bats.get(framenum).size(); bat_num++)
    {
      if(bats.get(framenum).get(bat_num).id != camera_id)
        bats.get(framenum).get(bat_num).init(gl,randcolor);
    }
      //for(Bats bat: bats)
      //{
      //    bat.init( gl );
      //}
  }

  public void update( GL2 gl, List<List<Bats>> bats, int framenum, int camera_id)
  {
    //tank.update( gl );
    //for(Bats bat: bats)
    //{
    //    bat.update( gl );
    //}

    //frame++;
    if(bats != null)
    if(bats.get(framenum)!=null)
    for(int bat_num = 0; bat_num < bats.get(framenum).size(); bat_num++)
    {
      if(bats.get(framenum).get(bat_num).id != camera_id)
        bats.get(framenum).get(bat_num).update(gl);
    }

  }

  public void draw( GL2 gl, List<List<Bats>> bats, int framenum, int camera_id)
  {
    //tank.draw( gl );

  if(bats != null)
    if(bats.get(framenum)!=null)
    for(int bat_num = 0; bat_num < bats.get(framenum).size(); bat_num++)
    {
      if(bats.get(framenum).get(bat_num).id != camera_id)
        bats.get(framenum).get(bat_num).draw(gl);
    }

    //if(bats != null)
    //for(Bats bat: bats)
    //{
    //  bat.draw( gl );
    //}
  }
}