import javax.imageio.ImageIO;
import javax.swing.*;

//import java.awt.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.media.opengl.GL;
import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.awt.GLCanvas;//for new version of gl
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;

import com.jogamp.opengl.util.GLBuffers;
import com.jogamp.opengl.util.gl2.GLUT;//for new version of gl
import com.jogamp.opengl.util.FPSAnimator;//for new version of gl

import static javax.media.opengl.GL.*;


public class FinalProject extends JFrame
        implements GLEventListener, KeyListener, MouseListener, MouseMotionListener
{
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private final int DEFAULT_WINDOW_WIDTH =640;
    private final int DEFAULT_WINDOW_HEIGHT=512;

    private GLCapabilities capabilities;
    private GLCanvas canvas;
    private FPSAnimator animator;
    private GLU glu;
    @SuppressWarnings("unused")
    private GLUT glut;
    private Draw_Space drawSpace;
    private Quaternion viewing_quaternion; // world rotation controlled by mouse actions
    public ui gui;


    public int frame = 1;
    public int bat_id = 14;

    // State variables for the mouse actions
    int last_x, last_y;
    boolean rotate_world;

    int collision_show = 1;

    public boolean write = false;

    public FinalProject()
    {

        gui = new ui(this);

        capabilities = new GLCapabilities(null);
        capabilities.setDoubleBuffered(true);  // Enable Double buffering

        canvas  = new GLCanvas(capabilities);
        canvas.addGLEventListener(this);
        canvas.addMouseListener(this);
        canvas.addMouseMotionListener(this);
        canvas.addKeyListener(this);
        canvas.setAutoSwapBufferMode(true); // true by default. Just to be explicit
        getContentPane().add(canvas);

        animator = new FPSAnimator(canvas, 60); // drive the display loop @ 60 FPS

        glu  = new GLU();
        glut = new GLUT();

        setTitle("FinalProject");
        setSize( DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        last_x = last_y = 0;
        rotate_world = false;

        // Set initialization code for user created classes that involves OpenGL
        // calls after here. After this line, the opengGl context will be
        // correctly initialized.
        drawSpace = new Draw_Space();
        viewing_quaternion = new Quaternion();

    }

    public void run()
    {
        gui.run();
        animator.start();
    }

    /*
    public void calculate_dir(List<List<Bats>> bats)
    {
        for(int frame_num = 0; frame_num < bats.size(); frame_num++)
        {
            for(int bats_num_currentframe = 0; bats_num_currentframe < bats.get(frame_num).size(); bats_num_currentframe++)
            {
                if(frame_num > 0)
                    for(int bats_num_lastframe = 0; bats_num_lastframe < bats.get(frame_num - 1).size(); bats_num_lastframe++)
                    {
                        int current_id = bats.get(frame_num).get(bats_num_currentframe).id;
                        int last_id = bats.get(frame_num-1).get(bats_num_lastframe).id;
                        if(current_id == last_id)
                        {
                            bats.get(frame_num).get(bats_num_currentframe).dir_x =  bats.get(frame_num).get(bats_num_currentframe).x -  bats.get(frame_num - 1).get(bats_num_lastframe).x;
                            bats.get(frame_num).get(bats_num_currentframe).dir_y =  bats.get(frame_num).get(bats_num_currentframe).y -  bats.get(frame_num - 1).get(bats_num_lastframe).y;
                            bats.get(frame_num).get(bats_num_currentframe).dir_z =  bats.get(frame_num).get(bats_num_currentframe).z -  bats.get(frame_num - 1).get(bats_num_lastframe).z;
                        }
                    }
            }
        }
    }
    */

    public static List<List<Bats>> bats = new ArrayList<List<Bats>>();

    public  List<List<Bats>> ui_bat = new ArrayList<List<Bats>>();

    public static void main( String[] args )
    {
        DOMParser domreader = new DOMParser();
        //List<List<Bats>> bats = new ArrayList<List<Bats>>();
        domreader.readxml("davis_2008a_3d.xml", bats);

        /*
        for(int frame_num = 0; frame_num < bats.size(); frame_num++)
        {
            System.out.print(" frame:" + frame_num);
            for(int bats_num_currentframe = 0; bats_num_currentframe < bats.get(frame_num).size(); bats_num_currentframe++) {
                System.out.print(" bats_id:" + bats.get(frame_num).get(bats_num_currentframe).id);
                System.out.print(" bats_x:" + bats.get(frame_num).get(bats_num_currentframe).x);
                System.out.print(" bats_y:" + bats.get(frame_num).get(bats_num_currentframe).y);
                System.out.println(" bats_z:" + bats.get(frame_num).get(bats_num_currentframe).z);
            }
            System.out.println("----------------------------");
        }
        */

        //this.calculate_dir(bats);
        for(int frame_num = 0; frame_num < bats.size(); frame_num++)
        {
            for(int bats_num_currentframe = 0; bats_num_currentframe < bats.get(frame_num).size(); bats_num_currentframe++)
            {
                if(frame_num > 0)
                    for(int bats_num_lastframe = 0; bats_num_lastframe < bats.get(frame_num - 1).size(); bats_num_lastframe++)
                    {
                        int current_id = bats.get(frame_num).get(bats_num_currentframe).id;
                        int last_id = bats.get(frame_num-1).get(bats_num_lastframe).id;
                        if(current_id == last_id)
                        {
                            bats.get(frame_num).get(bats_num_currentframe).dir_x =  bats.get(frame_num).get(bats_num_currentframe).x -  bats.get(frame_num - 1).get(bats_num_lastframe).x;
                            bats.get(frame_num).get(bats_num_currentframe).dir_y =  bats.get(frame_num).get(bats_num_currentframe).y -  bats.get(frame_num - 1).get(bats_num_lastframe).y;
                            bats.get(frame_num).get(bats_num_currentframe).dir_z =  bats.get(frame_num).get(bats_num_currentframe).z -  bats.get(frame_num - 1).get(bats_num_lastframe).z;
                        }
                    }
            }
        }

        for(int frame_num = 0; frame_num < bats.size(); frame_num++)
        {
            System.out.println(" frame:" + frame_num);
            for(int bats_num_currentframe = 0; bats_num_currentframe < bats.get(frame_num).size(); bats_num_currentframe++) {
                System.out.print(" bats_id:" + bats.get(frame_num).get(bats_num_currentframe).id);
                System.out.println(" bats_dir: [" + bats.get(frame_num).get(bats_num_currentframe).dir_x + ", " + bats.get(frame_num).get(bats_num_currentframe).dir_y + ", " + bats.get(frame_num).get(bats_num_currentframe).dir_z + "]");
            }
            System.out.println("----------------------------");
        }

        FinalProject P = new FinalProject();
        P.run();
    }

    public boolean calculate_fov = false;
    public float focal_length;
    float ppm = 5559.4f;


    public void calculate_in_FOV()
    {
        if(calculate_fov)
        {
            //for(int frame_num = 0; frame_num < bats.size(); frame_num++)
            //{
            //    for(int bats_num_currentframe = 0; bats_num_currentframe < bats.get(frame_num).size(); bats_num_currentframe++)
            //    {
            /*
            float up[] = new float[]{0, 1, 0};
            float camdir[] = new float[3];
            float Zc[] = new float[3];
            float Xc[] = new float[3];
            float Yc[] = new float[3];
            float right[] = new float[3];
            float perp[] = new float[3];

            float cam_x, cam_y, cam_z;

            // set frame 1, No 1 bat as the camera
            // world coordinate X(1,0,0) Y(0,1,0) Z(0,0,1)
            cam_x = bats.get(frame).get(cam_bat_num).x;
            cam_y = bats.get(frame).get(cam_bat_num).y;
            cam_z = bats.get(frame).get(cam_bat_num).z;
            //float mag = (float) Math.sqrt(camdir[0] * camdir[0] + camdir[1] * camdir[1] + camdir[2] * camdir[2]);
*/

            Point3D cam = new Point3D(bats.get(frame).get(cam_bat_num).x,bats.get(frame).get(cam_bat_num).y,bats.get(frame).get(cam_bat_num).z);

            /*
            //Rodorigous！！！！！！！！！！！！！！！！
            Vector3D origin_z = new Vector3D(0f,0f,1f);
            Vector3D camdir = new Vector3D(bats.get(frame).get(cam_bat_num).dir_x,bats.get(frame).get(cam_bat_num).dir_y,bats.get(frame).get(cam_bat_num).dir_z);
            //camdir.normalize();
            //origin_z.normalize();

            Vector3D rotationAxis = origin_z.crossProduct(camdir);
            float rotationAngle = (float)Math.acos(origin_z.dotProduct(camdir))/(float)Math.sqrt(origin_z.x * origin_z.x  + origin_z.y * origin_z.y + origin_z.z * origin_z.z)/(float)Math.sqrt(camdir.x * camdir.x  + camdir.y * camdir.y + camdir.z * camdir.z);

            rotationAxis.normalize();
            Vector3D right = new Vector3D((float)(Math.cos(rotationAngle) + rotationAxis.x * rotationAxis.x * (1 - Math.cos(rotationAngle))), (float)(rotationAxis.x * rotationAxis.y * (1 - Math.cos(rotationAngle) - rotationAxis.z * Math.sin(rotationAngle))), (float)(rotationAxis.y * Math.sin(rotationAngle) + rotationAxis.x * rotationAxis.z * (1 - Math.cos(rotationAngle))));
            Vector3D up = new Vector3D((float)(rotationAxis.z * Math.sin(rotationAngle) + rotationAxis.x * rotationAxis.y * (1 - Math.cos(rotationAngle))), (float)(Math.cos(rotationAngle) + rotationAxis.y * rotationAxis.y * (1 - Math.cos(rotationAngle))),(float)(-rotationAxis.x * Math.sin(rotationAngle) + rotationAxis.y * rotationAxis.z * (1 - Math.cos(rotationAngle))));
            Vector3D dir = new Vector3D((float)(-rotationAxis.y * Math.sin(rotationAngle) + rotationAxis.x * rotationAxis.z * (1 - Math.cos(rotationAngle))),(float)(rotationAxis.x * Math.sin(rotationAngle) + rotationAxis.y * rotationAxis.z * (1 - Math.cos(rotationAngle))),(float)(Math.cos(rotationAngle) + rotationAxis.z * rotationAxis.z * (1 - Math.cos(rotationAngle))));
*/



            Vector3D perp;
            Vector3D up = new Vector3D(0, 1, 0);
            Vector3D right;
            Vector3D dir = new Vector3D(bats.get(frame).get(cam_bat_num).dir_x,bats.get(frame).get(cam_bat_num).dir_y,bats.get(frame).get(cam_bat_num).dir_z);
            dir.normalize();
            right = dir.crossProduct(up);
            right.normalize();
            perp = right.crossProduct(dir);
            perp.normalize();

            float cos_x_perp = perp.dotProduct(new Vector3D(1,0,0));
            float cos_y_right = right.dotProduct(new Vector3D(0,1,0));
            float cos_z_dir = dir.dotProduct(new Vector3D(0,0,1));
            float cos_x_right = right.dotProduct(new Vector3D(1,0,0));
            float cos_y_perp = perp.dotProduct(new Vector3D(0,1,0));
            float cos_z_perp = perp.dotProduct(new Vector3D(0,0,1));
            float cos_x_dir = dir.dotProduct(new Vector3D(1,0,0));
            float cos_y_dir = dir.dotProduct(new Vector3D(0,1,0));
            float cos_z_right = right.dotProduct(new Vector3D(0,0,1));


            /*

            Vector3D up = new Vector3D(0,1,0);
            up.normalize();

            Vector3D right = camdir.crossProduct(up);
            right.normalize();

            up = camdir.crossProduct(right);
            up.normalize();
*/


            /*
            float[] zw = new float[]{0, 0, 1};
            float mag1, mag2, dotp, cos, theta, cos1, sin1, cos2, sin2, cos3, sin3;
            float[][] r1, r2, r3 = new float[3][3];

            // calculate x axis rotation matrix r1
            dotp = camdir[1] * zw[1] + camdir[2] * zw[2];
            mag1 = (float) Math.sqrt(camdir[1] * camdir[1] + camdir[2] * camdir[2]);
            mag2 = (float) Math.sqrt(zw[1] * zw[1] + zw[2] * zw[2]);
            cos1 = cos = dotp / (mag1 * mag2);
            theta = (float) Math.acos(cos);
            sin1 = (float) Math.sin(theta);

            // calculate z axis rotation matrix r2
            dotp = camdir[0] * zw[0] + camdir[1] * zw[1];
            if (dotp == 0) {
                cos2 = 1;
                sin2 = 0;
            } else {
                mag1 = (float) Math.sqrt(camdir[0] * camdir[0] + camdir[1] * camdir[1]);
                mag2 = (float) Math.sqrt(zw[0] * zw[0] + zw[1] * zw[1]);
                cos2 = cos = dotp / (mag1 * mag2);
                theta = (float) Math.acos(cos);
                sin2 = (float) Math.sin(theta);
            }

            // calculate y axis rotation matrix r3
            dotp = camdir[0] * zw[0] + camdir[2] * zw[2];
            mag1 = (float) Math.sqrt(camdir[0] * camdir[0] + camdir[2] * camdir[2]);
            mag2 = (float) Math.sqrt(zw[0] * zw[0] + zw[2] * zw[2]);
            cos3 = cos = dotp / (mag1 * mag2);
            theta = (float) Math.acos(cos);
            sin3 = (float) Math.sin(theta);

            // get rotation matrix
            //float [][] rotation_matrix = new float[3][3]{{cos2*cos3,cos2*sin3,-sin2},{sin1*sin2*cos3-cos1*sin3,sin1*sin2*sin3+cos1*cos3,sin1*cos2},{cos1*sin2*cos3+sin1*sin3, cos1*sin2*sin3-sin1*cos3, cos1*cos2}};


                /*
                // normalized
                //float mag = (float) Math.sqrt(camdir[0] * camdir[0] + camdir[1] * camdir[1] + camdir[2] * camdir[2]);
                Zc[0] = camdir[0];
                Zc[1] = camdir[1];
                Zc[2] = camdir[2];
                right[0] = camdir[1]*up[2]-camdir[2]*up[1];
                right[1] = camdir[2]*up[0]-camdir[0]*up[2];
                right[2] = camdir[0]*up[1]-camdir[1]*up[0];
                //mag = (float) Math.sqrt(right[0] * right[0] + right[1] * right[1] + right[2] * right[2]);
                Yc[0] = right[0];
                Yc[1] = right[1];
                Yc[2] = right[2];
                perp[0] = camdir[1]*right[2]-camdir[2]*right[1];
                perp[1] = camdir[1]*right[2]-camdir[2]*right[1];
                perp[2] = camdir[1]*right[2]-camdir[2]*right[1];
                //mag = (float) Math.sqrt(perp[0] * perp[0] + perp[1] * perp[1] + perp[2] * perp[2]);
                Xc[0] = perp[0];
                Xc[1] = perp[1];
                Xc[2] = perp[2];

                System.out.print(" cam_dir: " + Zc[0] + ", " + Zc[1] + ", " + Zc[2]);

                float transform_matrix[][] = new float[][]{{Zc[0],Zc[1],Zc[2],0},{Yc[0],Yc[1],Yc[2],0},{Zc[0],Zc[1],Zc[2],0},{-cam_x,-cam_y,-cam_z,1}};
                //float rotation_matrix[][] = new float[][]{{camdir[0],camdir[1],camdir[2],0},{right[0],right[1],right[2],0},{perp[0],perp[1],perp[2],0},{cam_x,cam_y,cam_z,1}};
*/
            System.out.println(" cam_location: " + cam.x + ", " + cam.y + ", " + cam.z);
            System.out.println(" cam_direction: " + dir.x + ", " + dir.y + ", " + dir.z);
            System.out.println(" frame: " + frame);
            //float h = (float)0.09210/2;
            //float h = (float)0.09210/2;
            float f = focal_length; // focal length
            //float f = 0.05f;
            //float f = h/(float)Math.tan((float)(aspect_angle/2)*Math.PI/180f);

            for (int bats_num_currentframe = 0; bats_num_currentframe < bats.get(frame).size(); bats_num_currentframe++) {
                float world_x, world_y, world_z, xc, yc, zc, xp, yp, zp;
                world_x = bats.get(frame).get(bats_num_currentframe).x - cam.x;
                world_y = bats.get(frame).get(bats_num_currentframe).y - cam.y;
                world_z = bats.get(frame).get(bats_num_currentframe).z - cam.z;

                //float [][] rotation_matrix = new float[3][3]{{cos2*cos3,cos2*sin3,-sin2},{sin1*sin2*cos3-cos1*sin3,sin1*sin2*sin3+cos1*cos3,sin1*cos2},{cos1*sin2*cos3+sin1*sin3, cos1*sin2*sin3-sin1*cos3, cos1*cos2}};

                //xc = bats.get(frame).get(bats_num_currentframe).xc = cos2 * cos3 * world_x + cos2 * sin3 * world_y + (-sin2) * world_z - cam_x;
                //yc = bats.get(frame).get(bats_num_currentframe).yc = (sin1 * sin2 * cos3 - cos1 * sin3) * world_x + (sin1 * sin2 * sin3 + cos1 * cos3) * world_y + (sin1 * cos2) * world_z - cam_y;
                //zc = bats.get(frame).get(bats_num_currentframe).zc = (cos1 * sin2 * cos3 + sin1 * sin3) * world_x + (cos1 * sin2 * sin3 - sin1 * cos3) * world_y + (cos1 * cos2) * world_z - cam_z;

                //xc = bats.get(frame).get(bats_num_currentframe).xc = transform_matrix[0][0]* world_x + transform_matrix[1][0]* world_y + transform_matrix[2][0]* world_z - cam_x;
                //yc = bats.get(frame).get(bats_num_currentframe).yc = transform_matrix[0][1]* world_x + transform_matrix[1][1]* world_y + transform_matrix[2][1]* world_z - cam_y;
                //zc = bats.get(frame).get(bats_num_currentframe).zc = transform_matrix[0][2]* world_x + transform_matrix[1][2]* world_y + transform_matrix[2][2]* world_z - cam_z;

                // RodRigous!!!!!
                //xc = bats.get(frame).get(bats_num_currentframe).xc = right.x* world_x + right.y* world_y + right.z* world_z;
                //yc = bats.get(frame).get(bats_num_currentframe).yc = up.x* world_x + up.y* world_y + up.z* world_z;
                //zc = bats.get(frame).get(bats_num_currentframe).zc = dir.x* world_x + dir.y* world_y + dir.z* world_z;

                //bats.get(frame).get(cam_bat_num).xc = cos_x_perp * cam.x + cos_x_right* cam.y + cos_x_dir* cam.z;
                //bats.get(frame).get(cam_bat_num).yc = cos_y_perp* cam.x + cos_y_right* cam.y + cos_y_dir* cam.z;
                //bats.get(frame).get(cam_bat_num).zc = cos_z_perp* cam.x + cos_z_right* cam.y + cos_z_dir* cam.z;

                Vector3D cosx = new Vector3D (cos_x_perp, cos_x_right, cos_x_dir);
                Vector3D cosy = new Vector3D (cos_y_perp, cos_y_right, cos_y_dir);
                Vector3D cosz = new Vector3D (cos_z_perp, cos_z_right, cos_z_dir);

                cosx.normalize();
                cosy.normalize();
                cosz.normalize();

                //DCM
                xc = bats.get(frame).get(bats_num_currentframe).xc = cosx.x * world_x + cosx.y* world_y + cosx.z* world_z;
                yc = bats.get(frame).get(bats_num_currentframe).yc = cosy.x* world_x + cosy.y* world_y + cosy.z* world_z;
                zc = bats.get(frame).get(bats_num_currentframe).zc = cosz.x* world_x + cosz.y* world_y + cosz.z* world_z;
                //xc = bats.get(frame).get(bats_num_currentframe).xc = cos_x_perp * world_x + cos_x_right* world_y + cos_x_dir* world_z;
                //yc = bats.get(frame).get(bats_num_currentframe).yc = cos_y_perp* world_x + cos_y_right* world_y + cos_y_dir* world_z;
                //zc = bats.get(frame).get(bats_num_currentframe).zc = cos_z_perp* world_x + cos_z_right* world_y + cos_z_dir* world_z;


                // projection
                xp = bats.get(frame).get(bats_num_currentframe).xp = f * bats.get(frame).get(bats_num_currentframe).xc / bats.get(frame).get(bats_num_currentframe).zc;
                yp = bats.get(frame).get(bats_num_currentframe).yp = f * bats.get(frame).get(bats_num_currentframe).yc / bats.get(frame).get(bats_num_currentframe).zc;
                zp = bats.get(frame).get(bats_num_currentframe).zp = f;

                float u = xp * ppm + 320f;
                float v = yp * ppm + 256f;


                //bats.get(1).get(bats_num_currentframe).xc = rotation_matrix[0][0]* cam_x + rotation_matrix[0][1]* cam_y + rotation_matrix[0][2]* cam_z - world_x;
                //bats.get(1).get(bats_num_currentframe).yc = rotation_matrix[1][0]* cam_x + rotation_matrix[1][1]* cam_y + rotation_matrix[1][2]* cam_z - world_y;
                //bats.get(1).get(bats_num_currentframe).zc = rotation_matrix[2][0]* cam_x + rotation_matrix[2][1]* cam_y + rotation_matrix[2][2]* cam_z - world_z;
                System.out.print(" projection_bats_id:" + bats.get(frame).get(bats_num_currentframe).id);
                System.out.print(" projection_bats_xc_yc_zc: [" + bats.get(frame).get(bats_num_currentframe).xc + ", " + bats.get(frame).get(bats_num_currentframe).yc + ", " + bats.get(frame).get(bats_num_currentframe).zc + "]");
                System.out.print(" projection_bats_xp_yp_zp: [" + bats.get(frame).get(bats_num_currentframe).xp + ", " + bats.get(frame).get(bats_num_currentframe).yp + ", " + bats.get(frame).get(bats_num_currentframe).zp + "]");
                System.out.println(" projection_u_v: [" + u + ", " + v + "]");
            }

            //for (int bats_num_currentframe = 0; bats_num_currentframe < bats.get(frame).size(); bats_num_currentframe++) {
                //if(bats.get(frame).get(bats_num_currentframe).zc > f)
                    //System.out.println("id: " + bats.get(frame).get(bats_num_currentframe).id + "is in the view");
            //}

        }

        calculate_fov = false;
        //    }
        //}
    }

    //public int camera_id;
    //public int camera_num;

    //***************************************************************************
    //GLEventListener Interfaces
    //***************************************************************************
    //
    // Place all OpenGL related initialization here. Including display list
    // initialization for user created classes
    //
    public void init( GLAutoDrawable drawable)
    {
        //String[] args = new String[]{"0"};
        //gui.run();
        //camera_id = bats.get(frame).get(bat_id).id;

        GL2 gl = (GL2)drawable.getGL();

        /* set up for shaded display of the drawSpace*/
        float light0_position[] = {0,0,0,1};
        float light0_ambient_color[] = {0.25f,0.25f,0.25f,1};
        float light0_diffuse_color[] = {1,1,1,1};

        gl.glPolygonMode(GL.GL_FRONT,GL2.GL_FILL);
        gl.glEnable(GL2.GL_COLOR_MATERIAL);
        gl.glColorMaterial(GL.GL_FRONT,GL2.GL_AMBIENT_AND_DIFFUSE);

        gl.glClearColor(0.0f,0.0f,0.0f,0.0f);
        gl.glShadeModel(GL2.GL_SMOOTH);

        /* set up the light source */
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, light0_position, 0);
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, light0_ambient_color, 0);
        gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_DIFFUSE, light0_diffuse_color, 0);

        /* turn lighting and depth buffering on */
        gl.glEnable(GL2.GL_LIGHTING);
        gl.glEnable(GL2.GL_LIGHT0);
        gl.glEnable(GL2.GL_DEPTH_TEST);
        gl.glEnable(GL2.GL_NORMALIZE);

        //drawSpace.init( gl, bats, frame,bat_num );
    }

    public int cam_bat_num = 0;
    public boolean no_this_id = false;
    public float aspect_angle = 35;

    public boolean autoplay = false;

    // Redisplaying graphics
    public void display(GLAutoDrawable drawable)
    {

        ui_bat = bats;
        //gui.update(this);

        GL2 gl = (GL2)drawable.getGL();

        // clear the display
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);

        gl.glMatrixMode(GL2.GL_MODELVIEW);
        gl.glLoadIdentity();

        // rotate the world and then call world display list object
        //gl.glMultMatrixf( viewing_quaternion.to_matrix(), 0 );


        if(autoplay) {
            frame++;
            try {
                Thread.sleep(40);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


        drawSpace.init( gl, bats, frame,bat_id);
        drawSpace.update( gl, bats, frame,bat_id);
        drawSpace.draw( gl, bats, frame,bat_id) ;


        reshape(drawable,0,0,getWidth(),getHeight());
        calculate_in_FOV();
    }

    public boolean batview = true;

    // Window size change
    public void reshape(GLAutoDrawable drawable, int x, int y,
                        int width, int height)
    {
        // Change viewport dimensions
        GL2 gl = (GL2) drawable.getGL();

        // Prevent a divide by zero, when window is too short (you cant make a
        // window of zero width).
        if (height == 0) height = 1;

        double ratio = 1.0f * width / height;

        // Reset the coordinate system before modifying
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();

        // Set the viewport to be the entire window
        gl.glViewport(0, 0, width, height);


        //aspect_angle = gui.slider1.getValue();
        //aspect_angle = gui.aspect;
        // Set the clipping volume
        float height_m = (float)0.09210/2;
        //float f = height_m/(float)Math.tan((float)(aspect_angle/2)*Math.PI/180f); // focal length
        float f = focal_length;


        aspect_angle = (float)(2 * (Math.atan(((float)512/ppm)/(focal_length * 2))*180.0f/Math.PI));

        glu.gluPerspective(aspect_angle, width / height, f, 100);

        // Camera positioned at (0,0,6), look at point (0,0,0), Up Vector (0,1,0)

        if (bats != null)
            if (bats.get(frame) != null)
                for (int bat_num = 0; bat_num < bats.get(frame).size(); bat_num++) {
                    if (bats.get(frame).get(bat_num).id == bat_id) {
                        cam_bat_num = bat_num;
                        no_this_id = false;
                        break;
                    } else {
                        no_this_id = true;
                        continue;
                    }
                }

        Vector3D perp;
        Vector3D up = new Vector3D(0, 1, 0);
        Vector3D right;
        Vector3D dir = new Vector3D(bats.get(frame).get(cam_bat_num).dir_x,bats.get(frame).get(cam_bat_num).dir_y,bats.get(frame).get(cam_bat_num).dir_z);
        //float mag = (float) Math.sqrt(camdir[0] * camdir[0] + camdir[1] * camdir[1] + camdir[2] * camdir[2]);
        //dir[0] = bats.get(frame).get(cam_bat_num).dir_x;
        //dir[1] = bats.get(frame).get(cam_bat_num).dir_y;
        //dir[2] = bats.get(frame).get(cam_bat_num).dir_z;

        dir.normalize();

        right = dir.crossProduct(up);
        right.normalize();

        //right[0] = dir[1] * up[2] - dir[2] * up[1];
        //right[1] = dir[2] * up[0] - dir[0] * up[2];
        //right[2] = dir[0] * up[1] - dir[1] * up[0];
        //mag = (float) Math.sqrt(right[0] * right[0] + right[1] * right[1] + right[2] * right[2]);
        //Yc[0] = right[0];
        //Yc[1] = right[1];
        //Yc[2] = right[2];

        perp = right.crossProduct(dir);
        perp.normalize();
        //perp[0] = dir[1] * right[2] - dir[2] * right[1];
        //perp[1] = dir[1] * right[2] - dir[2] * right[1];
        //perp[2] = dir[1] * right[2] - dir[2] * right[1];
        //mag = (float) Math.sqrt(perp[0] * perp[0] + perp[1] * perp[1] + perp[2] * perp[2]);
        //Xc[0] = perp[0];
        //Xc[1] = perp[1];
        //Xc[2] = perp[2];



        //glu.gluLookAt(0,0,12,0,0,0,0,1,0);
        if (batview)
            glu.gluLookAt(bats.get(frame).get(cam_bat_num).x, bats.get(frame).get(cam_bat_num).y, bats.get(frame).get(cam_bat_num).z,
                    bats.get(frame).get(cam_bat_num).x + 1 * bats.get(frame).get(cam_bat_num).dir_x, bats.get(frame).get(cam_bat_num).y + 1 * bats.get(frame).get(cam_bat_num).dir_y, bats.get(frame).get(cam_bat_num).z + 1 * bats.get(frame).get(cam_bat_num).dir_z,
                    perp.x, perp.y, perp.z);
        else
            glu.gluLookAt(0, 0, 12, 1, 1, 1, 0, 1, 0);
        //glu.gluLookAt(cam_bat.x,cam_bat.y,cam_bat.z,0,0,0,0,1,0);

        if (no_this_id)
            System.out.println("No this id in this frame");

        //gl.glMatrixMode(GL2.GL_MODELVIEW);

// save as image
        if (write) {
            try {
                BufferedImage screenshot = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
                Graphics graphics = screenshot.getGraphics();

                ByteBuffer buffer = GLBuffers.newDirectByteBuffer(width * height * 4);
                // be sure you are reading from the right fbo (here is supposed to be the default one)
                // bind the right buffer to read from
                gl.glReadBuffer(GL_BACK);
                // if the width is not multiple of 4, set unpackPixel = 1
                gl.glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, buffer);

                for (int h = 0; h < height; h++) {
                    for (int w = 0; w < width; w++) {
                        // The color are the three consecutive bytes, it's like referencing
                        // to the next consecutive array elements, so we got red, green, blue..
                        // red, green, blue, and so on..+ ", "
                        graphics.setColor(new Color((buffer.get() & 0xff), (buffer.get() & 0xff),
                                (buffer.get() & 0xff)));
                        buffer.get();   // consume alpha
                        graphics.drawRect(w, height - h, 1, 1); // height - h is for flipping the image
                    }
                }
                // This is one util of mine, it make sure you clean the direct buffer
                //BufferUtils.destroyDirectBuffer(buffer);

                File outputfile = new File("frame_" + frame + "_normal.png");
                ImageIO.write(screenshot, "png", outputfile);
            } catch (IOException ex) {
            }
            write = false;
        }
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged,
                               boolean deviceChanged)
    {
    }


    //***********************************************
    //          KeyListener Interfaces
    //***********************************************
    public void keyTyped(KeyEvent key)
    {
        switch ( key.getKeyChar() ) {
            case 'Q' :
            case 'q' : new Thread() {
                public void run()
                { animator.stop(); }
            }.start();
                System.exit(0);
                break;

            // set the viewing quaternion to 0 rotation
            case 'R' :
            case 'r' :
                viewing_quaternion.reset();
                break;

            // set the viewing quaternion to 0 rotation
            case 'F' :
            case 'f' : {
                frame++;
            }
                break;

            // set the viewing quaternion to 0 rotation
            case 'W' :
            case 'w' : {
                bats.get(frame).get(cam_bat_num).x+=0.1;
            }
            break;


            // set the viewing quaternion to 0 rotation
            case 'a' :
            case 'A' : {
                aspect_angle++;
            }
            break;

            case 'C' :
            case 'c' : {
                //if(collision_show == 1)
                //{
                    //drawSpace.predators.get(0).sphere_collision_show = true;
                    //drawSpace.fishes.get(0).sphere_collision_show = true;}
               // else
               //{
                   // drawSpace.predators.get(0).sphere_collision_show = false;
                    //drawSpace.fishes.get(0).sphere_collision_show = false;
               // }
                collision_show *= -1;
                break;
            }
            default :
                break;
        }
    }

    public void keyPressed(KeyEvent key)
    {
        switch (key.getKeyCode()) {
            case KeyEvent.VK_ESCAPE:
                new Thread()
                {
                    public void run()
                    {
                        animator.stop();
                    }
                }.start();
                System.exit(0);
                break;

            default:
                break;
        }
    }

    public void keyReleased(KeyEvent key)
    {
    }

    //**************************************************
    // MouseListener and MouseMotionListener Interfaces
    //**************************************************
    public void mouseClicked(MouseEvent mouse)
    {
    }

    public void mousePressed(MouseEvent mouse)
    {
        int button = mouse.getButton();
        if ( button == MouseEvent.BUTTON1 )
        {
            last_x = mouse.getX();
            last_y = mouse.getY();
            rotate_world = true;
        }
    }

    public void mouseReleased(MouseEvent mouse)
    {
        int button = mouse.getButton();
        if ( button == MouseEvent.BUTTON1 )
        {
            rotate_world = false;
        }
    }

    public void mouseMoved( MouseEvent mouse)
    {
    }

    public void mouseDragged( MouseEvent mouse )
    {
        if (rotate_world)
        {
            // vector in the direction of mouse motion
            int x = mouse.getX();
            int y = mouse.getY();
            float dx = x - last_x;
            float dy = y - last_y;

            // spin around axis by small delta
            float mag = (float) Math.sqrt( dx*dx + dy*dy );
            if(mag < 0.0001)
                return;

            float[] axis = new float[3];
            axis[0] = dy/ mag;
            axis[1] = dx/ mag;
            axis[2] = 0.0f;

            // calculate appropriate quaternion
            float viewing_delta = 3.1415927f / 180.0f; // 1 degree
            float s = (float) Math.sin( 0.5f*viewing_delta );
            float c = (float) Math.cos( 0.5f*viewing_delta );

            Quaternion Q = new Quaternion( c, s*axis[0], s*axis[1], s*axis[2]);
            viewing_quaternion = Q.multiply( viewing_quaternion );

            // normalize to counteract acccumulating round-off error
            viewing_quaternion.normalize();

            // Save x, y as last x, y
            last_x = x;
            last_y = y;
        }
    }

    public void mouseEntered( MouseEvent mouse)
    {
    }

    public void mouseExited( MouseEvent mouse)
    {
    }

    public void dispose(GLAutoDrawable drawable) {
        // TODO Auto-generated method stub

    }
}