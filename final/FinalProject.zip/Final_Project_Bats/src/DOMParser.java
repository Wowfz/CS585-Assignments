import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMParser {

    DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
    //Load and parse XML file into DOM
    public Document parse(String filePath) {
        Document document = null;
        try {
            //DOM parser instance
            DocumentBuilder builder = builderFactory.newDocumentBuilder();
            //parse an XML file into a DOM tree
            document = builder.parse(new File(filePath));
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return document;
    }

    public void readxml(String filepath, List<List<Bats>> bats) {

        DOMParser parser = new DOMParser();
        Document document = parser.parse(filepath);
        //get root element
        Element rootElement = document.getDocumentElement();

        //traverse child elements
        NodeList nodes = rootElement.getChildNodes();
        for (int i=0; i < nodes.getLength(); i++)
        {
            Node node = nodes.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element child = (Element) node;
                //process child element
            }
        }

        NodeList nodeList = rootElement.getElementsByTagName("frame");
        if(nodeList != null)
        {
            for (int i = 0 ; i < nodeList.getLength(); i++)
            {
                Element element = (Element)nodeList.item(i);
                System.out.println(" frame:" + element.getAttribute("number"));
                NodeList objectlist = element.getElementsByTagName("object");

                List<Integer> id_inlastframe = new ArrayList<>();
                List<Bats> batsinlastframe = new ArrayList<>();

                for(int j = 0; j < objectlist.getLength(); j++)
                {
                    Element obj_element = (Element)objectlist.item(j);
                    int id;
                    float x,y,z;
                    id = Integer.parseInt(obj_element.getAttribute("id"));
                    x = Float.parseFloat(obj_element.getAttribute("x"));
                    y = Float.parseFloat(obj_element.getAttribute("y"));
                    z = Float.parseFloat(obj_element.getAttribute("z"));
                    Bats bat_object = new Bats(id,x,y,z);
                    //System.out.print(" id:" + obj_element.getAttribute("id"));
                    //System.out.print(" x:" + obj_element.getAttribute("x"));
                    //System.out.print(" y:" + obj_element.getAttribute("y"));
                    //System.out.println(" z:" + obj_element.getAttribute("z"));

                    /*
                    boolean addtolist = false;
                    id_inlastframe.add(id);

                    for(int list_num = 0; list_num<bats.size(); list_num++)
                    {
                        if(id == bats.get(list_num).id)
                        {
                            bats.get(list_num).x = x;
                            bats.get(list_num).x = y;
                            bats.get(list_num).x = z;
                            addtolist = false;
                            break;
                        }
                        else
                            addtolist = true;
                    }

                    if(addtolist == true)
                        bats.add(bat_object);
                        */
                    batsinlastframe.add(bat_object);
                }

                bats.add(batsinlastframe);
                /*
                // delete which is not in next frame
                for(int list_num = 0; list_num < bats.size(); list_num++)
                {
                    boolean deleteit = false;
                    for (int framebats_num = 0; framebats_num < id_inlastframe.size(); framebats_num++) {
                        if (id_inlastframe.get(framebats_num) == bats.get(list_num).id)
                        {
                            deleteit = false;
                            break;
                        }
                        else
                            deleteit = true;
                    }
                    if(deleteit = true)
                    {
                        bats.remove(list_num);
                    }
                }

                // output each frame info
                for(int list_num = 0; list_num < bats.size(); list_num++)
                {
                    System.out.print(" bats_id:" + bats.get(list_num).id);
                    System.out.print(" bats_x:" + bats.get(list_num).x);
                    System.out.print(" bats_y:" + bats.get(list_num).y);
                    System.out.println(" bats_z:" + bats.get(list_num).z);
                }
                System.out.println("----------------------------");
                */
            }
        }
    }
}