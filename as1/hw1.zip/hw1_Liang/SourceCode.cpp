#include <opencv2/core/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <iostream>
#include <string>

using namespace cv;
using namespace std;

void tintImageGrey(Mat& image);
void FlipImageHorizontally(Mat& image);
void BlurringImage(Mat& image);

int main()
{
	Mat image;
	image = imread("input_face_image.jpg", IMREAD_COLOR); // Read the file

	if (image.empty())                      // Check for invalid input
	{
		cout << "Could not open or find the image" << std::endl;
		return 0;
	}

	tintImageGrey(image);  // TintImageGrey
	FlipImageHorizontally(image);  // FlipImageHorizontally

	for(int i =0; i<20;i++)
		BlurringImage(image);   // Running 20 times the blurring algorithm


	namedWindow("Display window", WINDOW_AUTOSIZE); // Create a window for display.
	imshow("Display window", image);                // Show our image inside it.

		//save image
	imwrite("output_face_image.jpg", image);

	waitKey(0); // Wait for a keystroke in the window
	return 0;
}

void FlipImageHorizontally(Mat& image)
{
	if (image.empty())
	{
		cout << "Error: image is unallocated" << endl;
		return;
	}
	int channels = image.channels();
	for (int row = 0; row < image.rows; row++)
	{
		//the .ptr method of the Mat class returns a pointer to the specifed row.
		//the type of the returned pointer is given inside the angle brackets
		//
		// The reason you might prefer to use this notation is because
		// Mat objects can be used to store other types of data too, not just unsigned char's.
		// However, the data member variable is always of unsigned char.
		unsigned char* rowPtr = image.ptr<unsigned char>(row);
		unsigned char temp_r, temp_g, temp_b;
		for (int col1 = 0, col2 = image.cols; col1 < image.cols / 2, col2 > image.cols / 2; col1++, col2--)
		{
			// Once you have a pointer to the beginning of the row, you still need to calculate
			// the index of the element of the row that you want to access
			int index1 = col1 * channels;	//0 is the red channel index, index1 is 1st half pixels
			int index2 = col2 * channels;	//0 is the red channel index, index2 is 2nd half pixels

			// Exchange the value of 1st half pixel and 2nd half pixel
			temp_r = rowPtr[index1]; //index is red
			temp_g = rowPtr[index1 + 1]; //index+1 is green
			temp_b = rowPtr[index1 + 2]; //index+2 is blue
			rowPtr[index1] = rowPtr[index2];
			rowPtr[index1 + 1] = rowPtr[index2 + 1];
			rowPtr[index1 + 2] = rowPtr[index2 + 2];
			rowPtr[index2] = temp_r;
			rowPtr[index2 + 1] = temp_g;
			rowPtr[index2 + 2] = temp_b;
		}
	}
}

void tintImageGrey(Mat& image)
{
	if (image.empty())
	{
		cout << "Error: image is unallocated" << endl;
		return;
	}
	int channels = image.channels();
	for (int row = 0; row < image.rows; row++)
	{
		//the .ptr method of the Mat class returns a pointer to the specifed row.
		//the type of the returned pointer is given inside the angle brackets
		//
		// The reason you might prefer to use this notation is because
		// Mat objects can be used to store other types of data too, not just unsigned char's.
		// However, the data member variable is always of unsigned char.
		unsigned char* rowPtr = image.ptr<unsigned char>(row);
		unsigned char r, g, b; //RGB color
		for (int col = 0; col < image.cols; col++)
		{
			// Once you have a pointer to the beginning of the row, you still need to calculate
			// the index of the element of the row that you want to access
			int index = col * channels;	//0 is the red channel index
			r = rowPtr[index]; //index is red
			g = rowPtr[index + 1]; //index+1 is green
			b = rowPtr[index + 2]; //index+2 is blue
			rowPtr[index] = (r + b + g) / 3;
			rowPtr[index + 1] = (r + b + g) / 3;
			rowPtr[index + 2] = (r + b + g) / 3;
		}
	}
}

void BlurringImage(Mat& image)
{
	if (image.empty())
	{
		cout << "Error: image is unallocated" << endl;
		return;
	}
	int channels = image.channels();
	for (int row = 1; row < image.rows - 1; row++)
	{
		//the .ptr method of the Mat class returns a pointer to the specifed row.
		//the type of the returned pointer is given inside the angle brackets
		//
		// The reason you might prefer to use this notation is because
		// Mat objects can be used to store other types of data too, not just unsigned char's.
		// However, the data member variable is always of unsigned char.
		unsigned char* rowPtr = image.ptr<unsigned char>(row);
		unsigned char* up_rowPtr = image.ptr<unsigned char>(row - 1);
		unsigned char* down_rowPtr = image.ptr<unsigned char>(row + 1);


		unsigned char r[8], g[8], b[8]; //RGB color of 8 nearby pixels

		for (int col = 0; col < image.cols; col++)
		{
			// Once you have a pointer to the beginning of the row, you still need to calculate
			// the index of the element of the row that you want to access
			int index = col * channels;	//0 is the red channel index

			r[0] = up_rowPtr[index - 3]; //index is red
			g[0] = up_rowPtr[index - 3 + 1]; //index+1 is green
			b[0] = up_rowPtr[index - 3 + 2]; //index+2 is blue
			r[1] = up_rowPtr[index]; //index is red
			g[1] = up_rowPtr[index + 1]; //index+1 is green
			b[1] = up_rowPtr[index + 2]; //index+2 is blue
			r[2] = up_rowPtr[index + 3]; //index is red
			g[2] = up_rowPtr[index + 3 + 1]; //index+1 is green
			b[2] = up_rowPtr[index + 3 + 2]; //index+2 is blue
			r[3] = rowPtr[index - 3]; //index is red
			g[3] = rowPtr[index - 3 + 1]; //index+1 is green
			b[3] = rowPtr[index - 3 + 2]; //index+2 is blue
			r[4] = rowPtr[index + 3]; //index is red
			g[4] = rowPtr[index + 3 + 1]; //index+1 is green
			b[4] = rowPtr[index + 3 + 2]; //index+2 is blue
			r[5] = down_rowPtr[index - 3]; //index is red
			g[5] = down_rowPtr[index - 3 + 1]; //index+1 is green
			b[5] = down_rowPtr[index - 3 + 2]; //index+2 is blue
			r[6] = down_rowPtr[index]; //index is red
			g[6] = down_rowPtr[index + 1]; //index+1 is green
			b[6] = down_rowPtr[index + 2]; //index+2 is blue
			r[7] = down_rowPtr[index + 3]; //index is red
			g[7] = down_rowPtr[index + 3 + 1]; //index+1 is green
			b[7] = down_rowPtr[index + 3 + 2]; //index+2 is blue

			int sum_r = 0, sum_g = 0, sum_b = 0;
			for(int i = 0; i < 8; i++)
			{
				sum_r += r[i];
				sum_g += g[i];
				sum_b += b[i];
			}

			rowPtr[index] = sum_r / 8;
			rowPtr[index + 1] = sum_g / 8;
			rowPtr[index + 2] = sum_b / 8;
		}
	}
}