#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <iostream>
#include <vector> 
#include <stdio.h>
#include <stdlib.h>
#include <opencv2/opencv.hpp>
#include<string>
#include<io.h>

using namespace cv;
using namespace std;

Mat src, src_gray, src_dn, src_new;
Vec3b bg_color;
vector<Point> contours;
Vec3b n8color;
int n8coord[8][2];
Vec3b maxvalue[5];
// confusion s t c
int confusion_matrix[4][3];

bool if_blob_color(Vec3b color, Vec3b n8color);
int filesnum = 0;
int TP = 0, FP = 0;
int triangle, square, circl, totalnum;
int sum_c = 0, sum_s = 0, sum_t = 0;
int total_anno_c = 0, total_anno_s = 0, total_anno_t = 0;
int total_detect_c = 0, total_detect_s = 0, total_detect_t = 0;

// Function header
void FindObjectsContours(const Mat &src1, Mat origin1);
bool same_color(Vec3b a, Vec3b b);
void getn8(int x, int y, int n8coord[8][2]);
void findshape(const Mat &src1);
string Int_to_String(int);

// main function
int main()
{
	for(int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
		{
			confusion_matrix[i][j] = 0;
		}

	char filename[100];
	Mat img[500];
	int img_num = 500;

	for (int i = 0; i < img_num ;i++)
	{
		sprintf(filename, "output/%d.png", i + 1000);
		img[i] = imread(filename);
		//... other operations
	}

	for (int imgi = 0; imgi < 500; imgi++)
	{
		cout << "imgi: " << imgi << endl;
		// Load source image and convert it to gray
		src = img[imgi];

		//Disnoise
		//fastNlMeansDenoisingColored(src, src, 7, 7, 3, 9);
		//blur(src, src, Size(3, 3));
		Mat erodeStruct = getStructuringElement(MORPH_RECT, Size(3, 3));

		// Create Window and display source image
		namedWindow("Source", CV_WINDOW_AUTOSIZE);
		imshow("Source", src);
		//namedWindow("dn", CV_WINDOW_AUTOSIZE);
		//imshow("dn", src);


		bg_color = src.at<Vec3b>(0, 0);

		//bg_color = src.at<Vec3b>(0, 0);
		Mat contour_output = Mat::zeros(src.size(), CV_8UC3);
		//contour_output = src;
		FindObjectsContours(src, contour_output);

		//Mat erodeStruct = getStructuringElement(MORPH_RECT, Size(3, 3));
		//erode(contour_output, contour_output, erodeStruct);

		namedWindow("result", CV_WINDOW_AUTOSIZE);
		imshow("result", contour_output);
		//sprintf(filename, "shapes_train2018/results1/%d.bmp", i + 1000);
		//imwrite(filename, src);
	//}
		findshape(src);
		string path;
		string temp;

		Mat test;

		sum_c = 0; sum_s = 0; sum_t = 0;

		string temp1 = Int_to_String(imgi + 1000);
		for (int annonum = 0; annonum <= 3; annonum++) {
			string temp2 = Int_to_String(annonum);
			path = "annotations/" + temp1 + "_" + "circle" + "_" + temp2 + ".png";
			test = imread(path);
			if (test.data)
			{
				sum_c += 1;
			}
		}
		path = "annotations/" + temp1 + "_" + "circle" + "_c_crowd.png";
		test = imread(path);
		if (test.data)
		{
			sum_c += 2;
		}


		for (int i = 0; i <= 3; i++) {
			string temp2 = Int_to_String(i);
			path = "annotations/" + temp1 + "_" + "triangle" + "_" + temp2 + ".png";
			test = imread(path);
			if (test.data)
			{
				sum_t += 1;
			}
		}
		path = "annotations/" + temp1 + "_" + "triangle" + "_c_crowd.png";
		test = imread(path);
		if (test.data)
		{
			sum_t += 2;
		}

		for (int i = 0; i <= 3; i++) {
			string temp2 = Int_to_String(i);
			path = "annotations/" + temp1 + "_" + "square" + "_" + temp2 + ".png";
			test = imread(path);
			if (test.data)
			{
				sum_s += 1;
			}
		}
		path = "annotations/" + temp1 + "_" + "square" + "_c_crowd.png";
		test = imread(path);
		if (test.data)
		{
			sum_s += 2;
		}

		cout << sum_s << endl;
		cout << sum_t << endl;
		cout << sum_c << endl;

		total_anno_c += sum_c;
		total_anno_s += sum_s;
		total_anno_t += sum_t;

		total_detect_c += circl;
		total_detect_s += square;
		total_detect_t += triangle;

		if (sum_s >= square)
		{
			TP += square;
		}
		else
		{
			TP += sum_s;
			FP += square - sum_s;
		}

		if (sum_c >= circl)
		{
			TP += circl;
		}
		else
		{
			TP += sum_c;
			FP += circl - sum_c;
		}

		if (sum_t >= triangle)
		{
			TP += triangle;
		}
		else
		{
			TP += sum_t;
			FP += triangle - sum_t;
		}
	}

	cout << "There are " << total_anno_s << " Squares " << total_anno_t << " Triangles " << total_anno_c << " Circles"<<endl;
	cout << "Detected   " << total_detect_s << " Squares " << total_detect_t << " Triangles " << total_detect_c << " Circles" << endl;
	cout << "TP = " << TP << endl;
	cout << "FP = " << FP << endl;
	cout << "Precision (= TP/(TP+FP)): " << ((float)TP / (float)(TP + FP));

	// Wait until keypress
	waitKey(0);
	return(0);
}

// if true think a and b arr same color
bool same_color(Vec3b a, Vec3b b)
{
	int threshold = 10;
	if (abs(a(0) - b(0)) < threshold && abs(a(1) - b(1)) < threshold && abs(a(2) - b(2)) < threshold)
		return true;
	return false;
}

void getn8(int x, int y, int n8coord[8][2])
{
	if (x > 0 && x < src.cols - 1 && y > 0 && y < src.rows - 1)
	{
		n8coord[0][0] = x - 1; n8coord[0][1] = y;
		n8coord[1][0] = x - 1; n8coord[1][1] = y + 1;
		n8coord[2][0] = x; n8coord[2][1] = y + 1;
		n8coord[3][0] = x + 1; n8coord[3][1] = y + 1;
		n8coord[4][0] = x + 1; n8coord[4][1] = y;
		n8coord[5][0] = x + 1; n8coord[5][1] = y - 1;
		n8coord[6][0] = x; n8coord[6][1] = y - 1;
		n8coord[7][0] = x - 1; n8coord[7][1] = y - 1;
	}
}

void FindObjectsContours(const Mat &src1, Mat origin1)
{
	Mat_<Vec3b> src = src1;
	Mat_ <Vec3b> origin = origin1;
	Vec3b color = src(0, 0);//��ȡԭͼ��(0, 0)��BGR��ɫֵ������ǻҶ�ͼ�񣬽�Vec3b��Ϊuchar
	vector <Vec3b> color_set;
	bool notincolor_set = false;
	vector<Vec3b> gray_value;
	vector<int> gray_num;
	vector<Vec3b> gray_major_value;


	//iterate over all pixels until a pixel with a 1-value is encountered
	for (int y = 0; y < src.rows; y++) {
		for (int x = 0; x < src.cols; x++) {
			color = src(x, y);

			//priority_queue<int, vector<int>> test = gray_value;

			// select 5 max gray_value
			bool incolor_set = false;
			for (int i = 0; i < gray_value.size(); i++)
			{
				if (color == gray_value.at(i))
				{
					incolor_set = true;
					gray_num.at(i)++;
					break;
				}
				incolor_set = false;
			}

			if (!incolor_set)
			{
				gray_value.push_back(color);
				gray_num.push_back(1);
			}
		}
	}

	//value Main Color
	vector<int> temp_num = gray_num;
	int in[5];
	for (int i = 0; i < 5; i++)
	{
		in[i] = 0;
	}
	for (int j = 0; j < 5; j++)
	{
		int max = temp_num.at(0);
		for (int i = 0; i < temp_num.size(); i++)
		{
			if (temp_num.at(i) > max)
			{
				max = temp_num.at(i);
				in[j] = i;
			}
		}
		temp_num.at(in[j]) = 0;
	}

	// 5 gray values which have most number

	for (int i = 0; i < 5; i++)
	{
		maxvalue[i] = gray_value.at(in[i]);
	}

	/*
	// show different
	int sum = 0;
	for (int i = 0; i < gray_num.size(); i++)
	{
		sum += gray_num.at(i);
		cout << "Value: " << gray_value.at(i) << "  Num: " << gray_num.at(i) << endl;
	}
	cout << "SUM: " << sum;
	*/

	for (int i = 0; i < 5; i++)
	{
		cout << "Main Color(Up to 5 kinds): " << maxvalue[i] << endl;
	}

	bg_color = maxvalue[0];

	for (int y = 1; y < src.rows - 1; y++) {
		for (int x = 1; x < src.cols - 1; x++) {
			color = src(x, y);
		

			bool findcontour = false;
			for (int i = 1; i < 5; i++)
			{
				if (abs(color(0) - maxvalue[i](0)) < 10 && abs(color(1) - maxvalue[i](1)) < 10 && abs(color(2) - maxvalue[i](2)) < 10)
				{
					findcontour = true;
					break;
				}
				findcontour = false;
			}

			if ((x > 0 && x < src.cols - 1 && y > 0 && y < src.rows - 1))
			{
				if (!same_color(color, bg_color))
				{
					getn8(x, y, n8coord);
					for (int i = 0; i < 8; i++)
					{

						n8color = src(n8coord[i][0], n8coord[i][1]);
						if (!same_color(n8color, color))
						{

							if (same_color(n8color, bg_color))
								//white contour background
							{
								origin(x, y)[0] = 255;
								origin(x, y)[1] = 255;
								origin(x, y)[2] = 255;
								break;
							}

							else if (if_blob_color(color, n8color))
							{
								//green contour background
								origin(x, y)[0] = 0;
								origin(x, y)[1] = 255;
								origin(x, y)[2] = 0;
								break;
							}

						}
						else
						{
							if (n8coord[i][0] == 0 || n8coord[i][1] == 0 || n8coord[i][0] == src.cols - 1 || n8coord[i][1] == src.rows - 1)
							{
								origin(n8coord[i][0], n8coord[i][1])[0] = 0;
								origin(n8coord[i][0], n8coord[i][1])[1] = 0;
								origin(n8coord[i][0], n8coord[i][1])[2] = 255;
								break;
							}
						}
					}
				}
			}
		}
	}
}

bool if_blob_color(Vec3b color, Vec3b n8color)
{
	for (int i = 0; i < 5; i++)
	{
		if (!same_color(color, bg_color) && !same_color(n8color,bg_color) && same_color(n8color,maxvalue[i]) && !same_color(color,maxvalue[i]))
		{
			return true;
		}
	}
	return false;
}

string Int_to_String(int n)
{
	ostringstream stream;
	stream << n; //nΪint����
	return stream.str();
}

bool the_color_used(Vec3b color, vector<Vec3b> used_colorset)
{
	for (int i = 0; i < used_colorset.size(); i++)
	{
		if (same_color(color, used_colorset.at(i)))
		{
			return true;
		}
	}
	return false;
}

bool the_color_used2(Vec3b color, vector<Vec3b> used_colorset2)
{
	for (int i = 0; i < used_colorset2.size(); i++)
	{
		if (same_color(color, used_colorset2.at(i)))
		{
			return true;
		}
	}
	return false;
}

bool if_main_color(Vec3b color)
{
	for (int i = 0; i < 5; i++)
	{
		if (!same_color(color, bg_color) && same_color(color, maxvalue[i]))
		{
			return true;
		}
	}
	return false;
}

void findshape(const Mat &src1)
{

	Mat_<Vec3b> src = src1;
	Vec3b color1;
	Vec3b color2;
	Vec3b colorbefore;
	Vec3b colorbefore2;
	int x, y, j, i;
	int circle1 = 0, triangle1 = 0, square1 = 0;
	int circle2 = 0, triangle2 = 0, square2 = 0;

	vector<Vec3b> used_colorset;
	vector<Vec3b> used_colorset2;

	for (x = 0; x < src.rows; x++) {
		for (y = 0; y < src.cols; y++) {
			if (y == 0)
			{
				Vec3b temp1,temp2;
				temp1 = src(x, y);
				if(if_main_color(temp1) && !same_color(temp1, bg_color) && !the_color_used(temp1, used_colorset))
					temp2 = src(x+1, y);

				if (same_color(temp1, temp2))
				{
					square1++;
					used_colorset.push_back(temp1);
				}
			}
			else if(y>=1)
			{
				color1 = src(x, y);
				colorbefore = src(x, y - 1);
				if (if_main_color(color1) && !same_color(color1, bg_color) && !the_color_used(color1, used_colorset) && same_color(colorbefore, bg_color))
				{
					for (i = x + 15; i < src.rows - 15; i++) {
						for (j = 0; j < src.cols; j++) {
							color2 = src(i, j);
							//colorbefore2 = src(i, j - 1);
							if (same_color(color1, color2) && !the_color_used(color1, used_colorset))
							{
								float angle = abs((float)(i - x) / (float)(j - y));
								if (angle < 2.5 && angle > 1.5)
								{
									triangle1++;
									cout << "Color: " << color2 << endl;
									cout << "x y: " << x << " " << y << endl;
									cout << "Triangle!" << endl;
								}
								else if (angle > 3)
								{
									square1++;
									cout << "Color: " << color2 << endl;
									cout << "x y: " << x << " " << y << endl;
									cout << "Square!" << endl;
								}
								else
								{
									circle1++;
									cout << "Color: " << color2 << endl;
									cout << "x y: " << x << " " << y << endl;
									cout << "Circle!" << endl;
								}

								used_colorset.push_back(color1);

							}
						}
					}
				}
			}

		}
	}

	/*
	for (x = 0; x < src.rows; x++) {
		for (y = src.cols - 2; y >=0; y--) {
			color1 = src(x, y); 
			colorbefore = src(x, y + 1);
			if (!same_color(color1, bg_color) && !the_color_used2(color1, used_colorset2) && same_color(colorbefore, bg_color))
			{
				for (i = x + 20 ; i < src.rows - 20; i++) {
					for (j = src.cols - 2; j >= 0; j--) {
						color2 = src(i, j);
						colorbefore = src(i, j + 1);
						if (same_color(color1, color2) && !the_color_used2(color1, used_colorset2) && same_color(colorbefore, bg_color))
						{
							float angle = abs((float)(i - x) / (float)(j - y));
							if (angle < 2.5 && angle > 1.5)
							{
								triangle2++;
								cout << "Color: " << color2 << endl;
								cout << "x y: " << x << " " << y << endl;
								cout << "Triangle!" << endl;
							}
							else if (angle > 3)
							{
								square2++;
								cout << "Color: " << color2 << endl;
								cout << "x y: " << x<< " "<< y << endl;
								cout << "Square!" << endl;
							}
							else
							{
								circle2++;
								cout << "Color: " << color2 << endl;
								cout << "x y: " << x << " " << y << endl;
								cout << "Circle!" << endl;
							}

							used_colorset2.push_back(color1);
							
						}
					}
				}
			}
		}
	}


	if(triangle1 < triangle2)
		triangle = triangle2;
	else triangle = triangle1;

	if (square1 < square2)
		square = square2;
	else square = square1;

	if (circle1 < circle2)
		circl = circle2;
	else circl = circle1;

	if (used_colorset.size() < used_colorset2.size())
		totalnum = used_colorset2.size();
	else totalnum = used_colorset.size();
	*/
	


	triangle = triangle1; square = square1;circl = circle1;

	/*
	if (triangle > 4)
	{
		triangle = 1;
	}
	if (square > 4)
	{
		square = 1;
	}
	if (circl > 4)
	{
		circl = 1;
	}
	*/

	//circle = totalnum - triangle - square;
	cout << "Total square in this image: " << square << endl;
	cout << "Total triangle in this image: " << triangle << endl;
	cout << "Total circle in this image: " << circl << endl;

}
